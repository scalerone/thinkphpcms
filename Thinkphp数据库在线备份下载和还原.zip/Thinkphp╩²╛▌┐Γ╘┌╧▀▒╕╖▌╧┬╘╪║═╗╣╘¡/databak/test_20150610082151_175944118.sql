/* This file is created by MySQLReback 2015-06-10 08:21:51 */
 /* 创建表结构 `customer` */
 DROP TABLE IF EXISTS `customer`;/* MySQLReback Separation */ CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `solutation` varchar(40) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `company` varchar(100) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `source` varchar(50) NOT NULL,
  `sdate` date NOT NULL,
  `job` varchar(50) NOT NULL,
  `web` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `createtime` datetime NOT NULL,
  `modifiedtime` datetime DEFAULT NULL,
  `note` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `customer` */
 INSERT INTO `customer` VALUES ('1','and111222','5555','(513) 378-3241','wqedwqqwewqeqeqweq','1353333asas辅导费','合作伙伴','2011-11-30','gfcggdgfd','www.topzyc.000','com333333sasas33888','2010-11-04 21:11:59','2015-06-10 07:40:47','dique010101010');/* MySQLReback Separation */