-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : thinkphpcms
-- 
-- Part : #1
-- Date : 2017-03-09 17:12:45
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `cms_admin`
-- -----------------------------
DROP TABLE IF EXISTS `cms_admin`;
;

-- -----------------------------
-- Records of `cms_admin`
-- -----------------------------
INSERT INTO `cms_admin` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cms_admin` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cms_admin` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cms_admin` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cms_article`
-- -----------------------------
DROP TABLE IF EXISTS `cms_article`;
;

-- -----------------------------
-- Records of `cms_article`
-- -----------------------------
INSERT INTO `cms_article` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
